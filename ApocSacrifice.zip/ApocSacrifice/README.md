# ApocSacrifice
here's like how it works basically (or well the waves of the apocalypse kinda that will happen) (all days mentioned in this are specifically referring to mc days, not irl days!!!):
- there is a timer, the timer is reset whenever a person dies (teams can be set up by the person using the datapack if they so wish and stuff)
- this timer is 3 (minecraft) days long, and whenever the timer finishes it triggers the apocalypse
- deaths as normal players are permanent
- the apocalypse resets to the first day after it has "finished" (creating an infinite loop ofc), each day a new event happens, every 3 days a major event happens, outside of those days minor events happen (like just a simple warden being spawned), it goes as follows

**day 1)** a warden is spawned, then later a wither is spawned (these are not meant to be fought! (but you can fight them if you want to). Zombies will spawn around you now (even in daylight)

day 2) a warden is spawned

**day 3)** all dead players will be resurrected into powerful juggernauts now, each with unique powers - their powers being effects such as jump, speed, etc, all never disappearing (except for a few due to certain limitations)

day 4) a warden is spawned

day 5) a warden is spawned

**day 6)** two withers are spawned, the first being a normal one, the one that spawns later being an invincible one that cannot move

day 7) a warden is spawned

day 8) the juggernauts all get night vision that lasts forever, and a warden is spawned

**day 9)** a special wither is spawned, it can teleport around to areas nearby players meaning it will keep hunting you down, weather and time/day cycles are turned off, the time is turned to night, and weather becomes far more extreme (lava, end crystals, wither skeleton spawning, etc)

- the datapack can be started and restarted with ``/function apocsacrifice:startgame``

there are like announcements/messages sent out when like a day starts, both explaining what the day will be like and also to remind players that they need to kill others in order to pause the apocalypse for like 3 days
this is also like partially done with blocks and such too due to having enemies spawn where players were in prior
so like, when a mob is about to spawn for instance, explosion effects (not damaging explosions tho) will play and some goat horn sounds will also play
for the powerful mobs i mean, zombies get to be silent cus their easy and not much of a problem 
and at the start of each day in the apocalypse a bell sound will play too
